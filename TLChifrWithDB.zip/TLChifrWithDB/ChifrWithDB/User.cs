﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChifrWithDB
{
    public class User
    {
        
        public int Id { get; set; }
        public string? ChifredMessage { get; set; }
        public int Biases { get; set; }
        
    }
}
